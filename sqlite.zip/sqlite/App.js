import React, { useState, useEffect } from 'react';
import { Text, View, TextInput, Button, Alert, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import * as SQLite from 'expo-sqlite';

// Open (or create) SQLite database
const db = SQLite.openDatabase('userdb.db');

// Login Screen
const LoginScreen = ({ navigation }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  useEffect(() => {
    // Create a users table if it doesn't exist
    db.transaction(tx => {
      tx.executeSql(
        `CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, password TEXT);`,
        [],
        () => console.log('Table created successfully'),
        (txObj, error) => console.log('Error', error)
      );
    });

    // Insert a test user (if none exists)
    db.transaction(tx => {
      tx.executeSql(
        `INSERT INTO users (username, password) VALUES (?, ?)`,
        ['testuser', '1234'],
        () => console.log('Test user added'),
        (txObj, error) => console.log('Error', error)
      );
    });
  }, []);

  const handleLogin = () => {
    db.transaction(tx => {
      tx.executeSql(
        `SELECT * FROM users WHERE username = ? AND password = ?;`,
        [username, password],
        (_, { rows }) => {
          if (rows.length > 0) {
            navigation.navigate('Home', { username });
          } else {
            Alert.alert('Invalid Credentials', 'Please try again.');
          }
        },
        (txObj, error) => console.log('Error', error)
      );
    });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Login</Text>
      <TextInput
        style={styles.input}
        placeholder="Username"
        value={username}
        onChangeText={setUsername}
      />
      <TextInput
        style={styles.input}
        placeholder="Password"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
      />
      <Button title="Login" onPress={handleLogin} />
    </View>
  );
};

// Home Screen
const HomeScreen = ({ route }) => {
  const { username } = route.params;

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Welcome, {username}!</Text>
    </View>
  );
};

// Navigation Setup
const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Login">
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="Home" component={HomeScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

// Styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    width: '100%',
    height: 50,
    borderColor: '#ccc',
    borderWidth: 1,
    marginBottom: 15,
    borderRadius: 5,
    paddingHorizontal: 10,
    backgroundColor: '#fff',
  },
});
